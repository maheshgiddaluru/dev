/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 4 Oct, 2018 9:47:00 PM                      ---
 * ----------------------------------------------------------------
 */
package com.myshop.cockpits.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedMyshopCockpitsConstants
{
	public static final String EXTENSIONNAME = "myshopcockpits";
	
	protected GeneratedMyshopCockpitsConstants()
	{
		// private constructor
	}
	
	
}
